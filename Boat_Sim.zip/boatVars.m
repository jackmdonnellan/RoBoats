%Jack Donnellan
%Sim Init v1.0; 1/21/19
%Run this script to initialize simulink params
close all; clear all; clc
xs = [0:.01:2]; %m
ys = [0:.01:1]; %m

%% Velocity Field Definition
A_field = 1;
a = 0;
b = 1;
f = a.*xs.^2 + b.*xs;
dfdx = (2.*a.*xs + b)';
U_field = (-pi.*A_field.*sin(pi.*f)'*cos(pi.*ys))'; %m/s
V_field = (pi.*A_field.*dfdx.*cos(pi.*f)'*sin(pi.*ys))'; %m/s
U_field_load = flipud(U_field);
V_field_load = flipud(V_field);
%Uncomment to zero out field
U_field= zeros(size(U_field));
V_field= zeros(size(V_field));
U_field_load= zeros(size(U_field));
V_field_load= zeros(size(V_field));
% quiver(xs,ys,U_field,V_field)

%% Boat Params
m_boat = 0.120; %kg
Izz_boat = 1;
% Izz_boat = 0.040*0.08; %kg*m
d_motors = 8; %distance between the centers of motor shafts, cm
d_cg = [0 0 0]; %distance from IMU to CG
k_drag_para = 1; 
k_drag_perp = 1; 
k_drag_rot = 1;

%% Actuator Params (Not currently used)
L_motor = 0.1;
kphi_motor = 0.3;
J_motor = 0.1;
b_motor = 0.01;
R_motor = 2.0;

%% Boat IC Definition
x0_boat = [0.5 0.5]; %m
v0_boat = [0 0]; %m/s
v0_boat_mag = norm(v0_boat);
alpha0_boat = atan2(v0_boat(2),v0_boat(1));
a0_boat = [0 0]; %m/s^2
theta0_boat = 0; %rad
theta_dot0_boat = 0; %rad/s
theta_ddot0_boat = 0; %rad/s^2

%% Control Params
kpx = 1;
kpy = 1;
kix = 0.1;
kiy = 0.1;

%% Sim Params
dt = 0.01;
use_imu_model = 0;
xd = 1.5;
yd = 0.5;
waypoints = [1.5 0.5;1.0 0.75; 0.5 0.5;1.0 0.25];

